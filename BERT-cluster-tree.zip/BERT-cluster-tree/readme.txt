central1.py用来判断矩阵差异性并进行聚类分析；
emoji-test.py用来尝试判断表情的（可以删）
emotion-graph是用来绘制情感图的；
emotion-heatmap是描述情感复杂度热力图的；
lat-lon是对评论数据进行格网划分，返回index
matrix也是绘制情感图的，但是是双箭头，最开始的版本
shannon计算熵值的
simmilarity也是计算相似性，用的是GCN，感觉结果不太对，所以暂时舍弃了
test_emotion是进行情感判断的；
comments_heatmap是表示评论数据分布热力图







整个区域的面积范围：（29.96674,31.365921）（113.68363,115.083129）


clear_duplicate.py清除重复的数据
|
judge_emotion.py进行情感分析
|
time.py根据时间划分（时间定在2020.2.12全域门禁）可有可无
|
lat-lon.py进行格网划分
|
seperate_grid.py细分格网，将中心区域格网进行细分（0.01度）
|
judge_commemt.py根据格网划分评论数据
|
emotion_graph_new.py是绘制图结构
|
tree.py是四叉树结构聚类分析


